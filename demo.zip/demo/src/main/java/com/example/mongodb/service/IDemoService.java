package com.example.mongodb.service;

import java.util.List;

import com.example.mongodb.entity.DemoBean;

public interface IDemoService {
   public List<DemoBean> query();
   public List<DemoBean> queryIs(DemoBean demoBean);
}
