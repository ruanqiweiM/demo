package com.example.mongodb.dao;

import java.util.List;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.mongodb.entity.DemoBean;

public class DemoDao implements MongoRepository<DemoBean, String>{

	public Page<DemoBean> findAll(Pageable arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void delete(String arg0) {
		// TODO Auto-generated method stub
		
	}

	public void delete(DemoBean arg0) {
		// TODO Auto-generated method stub
		
	}

	public void delete(Iterable<? extends DemoBean> arg0) {
		// TODO Auto-generated method stub
		
	}

	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}

	public boolean exists(String arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	public Iterable<DemoBean> findAll(Iterable<String> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	public DemoBean findOne(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	public <S extends DemoBean> S save(S arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	public <S extends DemoBean> long count(Example<S> arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	public <S extends DemoBean> boolean exists(Example<S> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	public <S extends DemoBean> Page<S> findAll(Example<S> arg0, Pageable arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	public <S extends DemoBean> S findOne(Example<S> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	public <S extends DemoBean> List<S> save(Iterable<S> entites) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<DemoBean> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<DemoBean> findAll(Sort sort) {
		// TODO Auto-generated method stub
		return null;
	}

	public <S extends DemoBean> S insert(S entity) {
		// TODO Auto-generated method stub
		return null;
	}

	public <S extends DemoBean> List<S> insert(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	public <S extends DemoBean> List<S> findAll(Example<S> example) {
		// TODO Auto-generated method stub
		return null;
	}

	public <S extends DemoBean> List<S> findAll(Example<S> example, Sort sort) {
		// TODO Auto-generated method stub
		return null;
	}

}
