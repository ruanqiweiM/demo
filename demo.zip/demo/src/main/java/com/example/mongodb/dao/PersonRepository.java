package com.example.mongodb.dao;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.mongodb.entity.DemoBean;

public interface PersonRepository extends MongoRepository<DemoBean, String>{

}
