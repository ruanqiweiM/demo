package com.example.mongodb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.example.mongodb.entity.DemoBean;

@Service("demoService")
public class DemoService implements IDemoService{
	@Autowired
    private MongoTemplate mongoTemplate;
	public List<DemoBean> query() {
		// TODO Auto-generated method stub
		List<DemoBean> demoBeans =mongoTemplate.find(new Query(), DemoBean.class,"list2");
		return demoBeans;
	}
	public List<DemoBean> queryIs(DemoBean demoBean) {
		Query query = new Query(Criteria.where("name").is(demoBean.getName()));
		List<DemoBean> demoBeans =mongoTemplate.find(query, DemoBean.class,"list2");
		return demoBeans;
	}

}
