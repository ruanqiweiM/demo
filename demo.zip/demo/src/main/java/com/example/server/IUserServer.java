package com.example.server;

import java.util.List;

import com.example.entity.UserBean;

public interface IUserServer {
  public List<UserBean>queryUserList(int pageNo,int pageSize);
}
