package com.example.server.impl;

import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.UserBean;
import com.example.mapper.IUserMapper;
import com.example.server.IUserServer;
@Service("iUserServer")
public class UserServerImpl implements IUserServer{
	@Autowired
     private IUserMapper iUserMapper;
	public List<UserBean> queryUserList(int pageNo,int pageSize) {
		
		return iUserMapper.queryUserList(pageNo,pageSize);
	}

}
