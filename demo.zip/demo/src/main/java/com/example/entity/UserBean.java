package com.example.entity;

public class UserBean {
	private long f_id;
	private String f_user_name;
	private String f_password;
	private String f_update_time;
	private String f_add_time;
	private int f_sex;
	public long getF_id() {
		return f_id;
	}
	public void setF_id(long f_id) {
		this.f_id = f_id;
	}
	public String getF_user_name() {
		return f_user_name;
	}
	public void setF_user_name(String f_user_name) {
		this.f_user_name = f_user_name;
	}
	public String getF_password() {
		return f_password;
	}
	public void setF_password(String f_password) {
		this.f_password = f_password;
	}
	public String getF_update_time() {
		return f_update_time;
	}
	public void setF_update_time(String f_update_time) {
		this.f_update_time = f_update_time;
	}
	public String getF_add_time() {
		return f_add_time;
	}
	public void setF_add_time(String f_add_time) {
		this.f_add_time = f_add_time;
	}
	public int getF_sex() {
		return f_sex;
	}
	public void setF_sex(int f_sex) {
		this.f_sex = f_sex;
	}

}
