package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mongodb.entity.DemoBean;
import com.example.mongodb.service.IDemoService;

@RestController
@EnableAutoConfiguration
public class DemoConreoller {
	@Autowired
	private IDemoService iDemoService;
	@RequestMapping("findList")
    public Object findList(){
       return iDemoService.query();
    }
	
	@RequestMapping("findListIsName")
    public Object findList(DemoBean demoBean){
		if(demoBean ==null){
			demoBean = new DemoBean();
			demoBean.setName("����");
		}else if(demoBean !=null && demoBean.getName()==null){
			demoBean.setName("����");
		}
       return iDemoService.queryIs(demoBean);
    }
}
