package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.server.IUserServer;

@RestController
@EnableAutoConfiguration
public class HelloController {
	@Autowired
	private StringRedisTemplate stringRedisTemplate;
	/*@Autowired
	private RedisTemplate<String, Object> redisTemplate;*/
	@Autowired
	private IUserServer iUserServer;
	
	@RequestMapping("/helloWord")
    public  String helloWord(){
    	return "hello word!";
    }
	@RequestMapping("/queryUserInfo")
	public Object queryUserInfo(@RequestParam(defaultValue="1")int pageNo,@RequestParam(defaultValue="10")int pageSize){
		return iUserServer.queryUserList(pageSize*(pageNo-1),pageSize);
	}
	@RequestMapping("/testRedis")
	public String testRedis(){
		stringRedisTemplate.opsForValue().set("1111w", Math.random()+"");
		String info =stringRedisTemplate.opsForValue().get("1111w");
		System.out.println(info);
		/*List<UserBean> userBeans = iUserServer.queryUserList(1,10);
		for (UserBean userBean : userBeans) {
			redisTemplate.opsForValue().set(userBean.getF_user_name(), userBean);
			System.out.println(redisTemplate.opsForValue().get("����2"));
			System.out.println(redisTemplate.opsForValue().get("����5"));
		}*/
		
		return "hello word";
	}
    
}
