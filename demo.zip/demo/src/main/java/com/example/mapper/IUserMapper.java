package com.example.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.entity.UserBean;

@Mapper
public interface IUserMapper {
	public List<UserBean>queryUserList(@Param("pageNo")int pageNo,@Param("pageSize")int pageSize);
}
